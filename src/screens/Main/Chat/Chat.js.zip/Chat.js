import React from 'react';
import {View,Text,StyleSheet,Image,TouchableOpacity,FlatList,ActivityIndicator,TextInput} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
// import {Input, Button} from 'react-native-elements';
// import LinearGradient from 'react-native-linear-gradient'
import Icon from 'react-native-vector-icons/FontAwesome';
import IconFeat from 'react-native-vector-icons/Feather';
// import { Searchbar } from 'react-native-paper';
import IconFantiso from 'react-native-vector-icons/Fontisto';
import { GiftedChat,Actions,AvatarProps,Bubble,BubbleProps,Send,SendProps,RenderMessageImageProps,InputToolbar,Composer,ComposerProps } from 'react-native-gifted-chat'
//import Home from './Home';
//import ImagePicker from 'react-native-image-crop-picker';
import Iconic from 'react-native-vector-icons/dist/Ionicons';
import { IconButton } from 'react-native-paper';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
class Chat extends React.Component {
   state = {
        messages: [],
        check:true,
        TextValue : ''
      } 

      renderCustomActions(props) {
        return (
        <Home
        {...props}
        />
        );
        }
      // componentWillMount() {
      //   this.setState({
      //     messages: [
      //       {
      //         _id: 130,
      //         text: '',
      //         image: 'https://images.pexels.com/photos/67636/rose-blue-flower-rose-blooms-67636.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      //         video: undefined,
      //         createdAt: '2019-06-16T04:23:36.663Z',
      //         user: { 
      //           _id: 22,
      //           name: 'jc',
      //           avatar:  'https://placeimg.com/140/140/any'
      //         }
      //       } 
      //     ],
      //   })
      // }

     
      // GetValueFunction = (ValueHolder) =>{
      
      //   var Value = ValueHolder.length.toString() ;
   
      //   this.setState({TextValue : Value}) ;
      //   console.log("yeah",this.state.TextValue)
      //   if (Value>=1){
      //       this.state.check = false
      //       this.forceUpdate()
      //   }else{
      //       this.state.check = true
      //       this.forceUpdate()
      //   }
      
      //  }
      

      takePhotoFromGalary = ()=>{
        ImagePicker.openPicker({
            width: 300,
            height: 400,
            cropping: true
          }).then(image => {
            console.log(image);
          });
          
    
    }
 
       renderLoading =()=> {
        return (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#6646ee" />
          </View>
        );
      }
      handleSend =(newMessage = [])=> {
        setMessages(GiftedChat.append(messages, newMessage));
      }

      onSend(messages = []) {
        this.setState(previousState => ({
          messages: GiftedChat.append(previousState.messages, messages),
        }))
      }
      renderSendBtn = (props) =>{
        return (
          <Send {...props}>
            <View style={styles.sendingContainer}>
              
                <View style={{height:35,right:5,width:35,backgroundColor:"orange",alignSelf:"center",justifyContent:"center",borderRadius:35/2,bottom:5}}>
              <IconButton icon="send" size={20} color="white" 
              style={{alignSelf:"center"}}
              />

              </View>
              
            </View>
          </Send>
        );
      }
      //You can use send icon rather then send button
      
       renderCamera = (props) =>{
        return (
            
          <Send {...props}>
            <View style={styles.sendingContainer}>
                <TouchableOpacity onPress = {()=> this.takePhotoFromGalary()}>
                <View style={{height:35,right:5,width:35,backgroundColor:"orange",alignSelf:"center",justifyContent:"center",borderRadius:35/2,bottom:5}}>
              <IconButton icon="camera" size={20} color="white" 
              style={{alignSelf:"center"}}
              />

              </View>
              </TouchableOpacity>
            </View>
          </Send>
        );
      }
      
      renderInputToolbar = (props) =>{

        return(

          <InputToolbar 
          {...props} 
         containerStyle={{borderTopColor:"transparent",borderRadius:20,height:50,alignSelf:"center",backgroundColor:"#EFEFEF",}}
          >
              
           
          </InputToolbar>
        )
      }
       RenderBubble = (props)=> {
        return (
          // Step 3: return the component
          <Bubble
            {...props}
            
            wrapperStyle={{
              right: {
                // Here is the color change
                backgroundColor: 'red',
                
                
                
              }
            }}
            wrapperStyle={{
                left: {
                  // Here is the color change
                  backgroundColor: 'orange',
                  
                  
                }
              }}
              
              
            
            textStyle={{
              right: {
                color: '#fff'
              }
              
            }}
            textStyle={{
                left: {
                  color: 'white'
                }
                
              }}
          />
        );
      }
      
       scrollToBottomComponent = ()=> {
        return ( 
          <View style={styles.bottomComponentContainer}>
            <IconButton icon="chevron-double-down" size={36} color="#6646ee" />
          </View>
        );
      }
    render(){
        return(
            

            <View style={{flex:1,width:"100%",backgroundColor:"white",}}>
                <View style={{height:"3%",width:"100%",backgroundColor:"transparent"}}>

                </View>
                <View style={{height:40,width:"100%",backgroundColor:"transparent",flexDirection:"row",borderBottomColor:"lightgray",borderBottomWidth:0.3}}>
                   
                   <View style={{height:"100%",width:"15%",backgroundColor:"transparent",justifyContent:"center",alignSelf:"center",}}>    
                   <TouchableOpacity onPress ={()=> this.props.navigation.goBack()}>
               <Iconic
                   name="arrow-back"
                   size = {20}
                   style={{alignSelf:"center"}}
                   color={"orange"}
                   onPress={() => this.props.navigation.goBack()}
                   />
                   </TouchableOpacity>
                  
                       </View>
                       <View style={{height:"100%",width:"85%",backgroundColor:"transparent",justifyContent:"center"}}>
                           <View style={{height:"100%",width:"100%",backgroundColor:"transparent",justifyContent:"center"}}>
                               {/* <Text style={{fontSize:17,color:"black",fontWeight:"bold"}}>
                                  Chat
                                   </Text> */}
                               </View>
                              
                           </View>
                           
               </View>
           
                 <View style={{height:"80%",width:"100%",backgroundColor:"transparent"}}>
                <GiftedChat
                //  textInputStyle={styles.composer}
              // alwaysShowSend
              showAvatarForEveryMessage
              scrollToBottom
              isAnimated
            // renderInputToolbar = {this.renderInputToolbar}
              renderBubble={this.RenderBubble}
              renderLoading={this.renderLoading}
            //  onInputTextChanged ={ ValueHolder => this.GetValueFunction(ValueHolder) }
              renderSend=  {
                  // this.state.check === true ? this.renderCamera : this.renderSendBtn
                  this.renderSendBtn
              }
             
              
                showUserAvatar = {true}
        messages={this.state.messages}
      // onSend={newMessage => this.handleSend(newMessage)}
        scrollToBottomComponent={this.scrollToBottomComponent}
       onSend={messages => this.onSend(messages)}
        
        user={{
          _id: 1,
        }}
      />
      </View>
                </View>


        );
}
}
const styles = StyleSheet.create({
    sendingContainer: {
        backgroundColor:"transparent",
      justifyContent: 'center',
      alignItems: 'center',
     
      
    },
    bottomComponentContainer: {
        justifyContent: 'center',
        alignItems: 'center'
      },
      loadingContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
      },
      composer:{
        
        borderRadius: 25, 
        borderWidth: 0.5,
        borderColor: 'red',
        marginTop: 10,
        marginBottom: 10,
        paddingLeft: 10,
        paddingTop: 5,
        paddingBottom: 5,
        paddingRight: 10,
        fontSize: 16,
        
      },
      btnSend: {
        height: 40,
        width: 40,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 10,
        backgroundColor: "green",
        
        borderRadius: 50
      }
  });
    export default Chat;